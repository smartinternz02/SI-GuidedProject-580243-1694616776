package com.example.kotlin2

import android.R
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.support.v4.os.IResultReceiver.Default
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.tooling.preview.Preview
import com.example.kotlin2.ui.theme.Kotlin2Theme
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.material.icons.filled.Email
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.getValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.width
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.RadioButton

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LoginScreen()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen() {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var selectedWebsite by remember { mutableStateOf("") }
    val context = LocalContext.current

    val websites = listOf("Amazon", "Google", "Facebook", "Twitter")
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(Color(0xFFABCDEF)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_menu_search),
            contentDescription = "Login Image",
            modifier = Modifier
                .size(150.dp)
                .padding(16.dp)
        )
        Text(
            text = "Login",
            style = MaterialTheme.typography.headlineMedium.copy(color = Color(0xFF476810))
        )
        Spacer(modifier = Modifier.height(16.dp))
        //Username TextField
        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text(text = "Username") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        //Password TextField
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text(text = "Password")},
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction =ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = {
                    // Handle login here
                }
            ),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        // Radio Buttons for Website Selection
        websites.forEach { website ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = website == selectedWebsite,
                    onClick = {
                        selectedWebsite = website
                    }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = website)
            }
        }

        // Login Button
        Button(
            onClick = {
                if (selectedWebsite.isNotEmpty()) {
                    // Create an intent to open the selected website
                    val intent = Intent(Intent.ACTION_VIEW)
                    when (selectedWebsite) {
                        "Amazon" -> intent.data = Uri.parse("https://www.amazon.com")
                        "Google" -> intent.data = Uri.parse("https://www.google.com")
                        "Facebook" -> intent.data = Uri.parse("https://www.facebook.com")
                        "Twitter" -> intent.data = Uri.parse("https://www.twitter.com")
                    }
                    intent.setPackage("com.android.chrome")

                    try {
                        //Attempt to start the activity for opening the link
                        context.startActivity(intent)
                    } catch (e: ActivityNotFoundException) {
                        //Handle the case where there is no web browser available
                    }

                } else {
                    Toast.makeText(context, "Please select a website", Toast.LENGTH_LONG).show()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Open Website")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewLoginScreen(){
    LoginScreen()
}

