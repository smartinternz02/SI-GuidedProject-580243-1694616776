package com.example.hotelapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Dish33(val title: String, val imageDish: Int)

@Composable
fun Menu33(){

    val dishes33 = listOf(
        Dish33("Chicken Tikka", R.drawable.chicken_tikka),
        Dish33("BBQ Steak Sandwich", R.drawable.bbq_steaksandwich),
        Dish33("BBQ Kebabs", R.drawable.bbq_kebabs)
    )

    LazyColumn{
        items(dishes33) { dish33 ->
            DishItem33(dish33 = dish33)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DishItem33(dish33: Dish33) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        onClick = {
            // Handle movie item click
        }
    ) {
        Column (
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ){
            Image(
                painter = painterResource(id = dish33.imageDish),
                contentDescription = dish33.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = dish33.title, fontWeight = FontWeight.Bold)
        }
    }
}