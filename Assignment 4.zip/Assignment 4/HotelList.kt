package com.example.hotelapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

data class Hotel(val id: Int, val name: String, val imageResId: Int)

@Composable
fun HotelList(navController: NavController) {
    val hotels = listOf(
        Hotel(1, "Hotel 1", R.drawable.hotel1),
        Hotel(2, "Hotel 2", R.drawable.hotel2),
        Hotel(3, "Hotel 3", R.drawable.hotel3)
    )

    LazyColumn {
        items(hotels) { hotel ->
            HotelListItem(hotel, navController)
        }
    }
}

@Composable
fun HotelListItem(hotel: Hotel, navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clickable {
                // Navigate to the hotel page when clicked
                navController.navigate("hotel${hotel.id}")
            }
    ) {
        Image(
            painter = painterResource(id = hotel.imageResId),
            contentDescription = "Hotel Image",
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            contentScale = ContentScale.Crop
        )

        Text(
            text = hotel.name,
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier
                .padding(vertical = 8.dp)
        )
    }
}
