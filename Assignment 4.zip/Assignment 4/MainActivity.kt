package com.example.hotelapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun HotelApp(){
    val navController = rememberNavController()

    NavHost(
        navController =navController,
        startDestination = "loginScreen"
    ) {
        composable("loginScreen") { LoginScreen(navController) }
        composable("hotelList") { HotelList(navController) }
        composable("hotel1") { Hotel1(navController) }
        composable("hotel2") { Hotel2(navController) }
        composable("hotel3") { Hotel3(navController) }
        composable("menu11") { Menu11() }
        composable("menu12") { Menu12() }
        composable("menu13") { Menu13() }
        composable("menu21") { Menu21() }
        composable("menu22") { Menu22() }
        composable("menu23") { Menu23() }
        composable("menu31") { Menu31() }
        composable("menu32") { Menu32() }
        composable("menu33") { Menu33() }
    }
}

@Preview
@Composable
fun MyAppPreview() {
    HotelApp()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HotelApp()
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    MyAppPreview()
}
