package com.example.hotelapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

data class Menu1(val id: Int, val name: String, val imageResId: Int)

@Composable
fun Hotel1(navController: NavController) {
    val menulist1 = listOf(
        Menu1(11, "Biryani", R.drawable.menu11),
        Menu1(12, "Naan", R.drawable.menu12),
        Menu1(13, "Curry", R.drawable.menu13)
    )

    LazyColumn {
        items(menulist1) { menu1 ->
            MenuListItem1(menu1, navController)
        }
    }
}

@Composable
fun MenuListItem1(menu1: Menu1, navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clickable {
                // Navigate to the hotel page when clicked
                navController.navigate("menu${menu1.id}")
            }
    ) {
        Image(
            painter = painterResource(id = menu1.imageResId),
            contentDescription = "Menu Image",
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            contentScale = ContentScale.Crop
        )

        Text(
            text = menu1.name,
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier
                .padding(vertical = 8.dp)
        )
    }
}
