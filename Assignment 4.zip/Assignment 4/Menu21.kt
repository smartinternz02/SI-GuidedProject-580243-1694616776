package com.example.hotelapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Dish21(val title: String, val imageDish: Int)

@Composable
fun Menu21(){

    val dishes21 = listOf(
        Dish21("Veg Fried Rice", R.drawable.veg_friedrice),
        Dish21("Egg Fried Rice", R.drawable.egg_friedrice),
        Dish21("Pork Fried Rice", R.drawable.pork_friedrice)
    )

    LazyColumn{
        items(dishes21) { dish21 ->
            DishItem21(dish21 = dish21)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DishItem21(dish21: Dish21) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        onClick = {
            // Handle movie item click
        }
    ) {
        Column (
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ){
            Image(
                painter = painterResource(id = dish21.imageDish),
                contentDescription = dish21.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = dish21.title, fontWeight = FontWeight.Bold)
        }
    }
}