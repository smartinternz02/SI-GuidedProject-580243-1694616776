package com.example.hotelapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

data class Menu3(val id: Int, val name: String, val imageResId: Int)

@Composable
fun Hotel3(navController: NavController) {
    val menulist3 = listOf(
        Menu3(31, "Grilled Meat", R.drawable.menu31),
        Menu3(32, "Grilled Seafood", R.drawable.menu32),
        Menu3(33, "BBQ", R.drawable.menu33)
    )

    LazyColumn {
        items(menulist3) { menu3 ->
            MenuListItem3(menu3, navController)
        }
    }
}

@Composable
fun MenuListItem3(menu3: Menu3, navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clickable {
                // Navigate to the hotel page when clicked
                navController.navigate("menu${menu3.id}")
            }
    ) {
        Image(
            painter = painterResource(id = menu3.imageResId),
            contentDescription = "Menu Image",
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            contentScale = ContentScale.Crop
        )

        Text(
            text = menu3.name,
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier
                .padding(vertical = 8.dp)
        )
    }
}
