package com.example.hotelapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

data class Menu2(val id: Int, val name: String, val imageResId: Int)

@Composable
fun Hotel2(navController: NavController) {
    val menulist1 = listOf(
        Menu2(21, "Fried Rice", R.drawable.menu21),
        Menu2(22, "Chow mein", R.drawable.menu22),
        Menu2(23, "Dumplings", R.drawable.menu23)
    )

    LazyColumn {
        items(menulist1) { menu2 ->
            MenuListItem2(menu2, navController)
        }
    }
}

@Composable
fun MenuListItem2(menu2: Menu2, navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clickable {
                // Navigate to the hotel page when clicked
                navController.navigate("menu${menu2.id}")
            }
    ) {
        Image(
            painter = painterResource(id = menu2.imageResId),
            contentDescription = "Menu Image",
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            contentScale = ContentScale.Crop
        )

        Text(
            text = menu2.name,
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier
                .padding(vertical = 8.dp)
        )
    }
}
