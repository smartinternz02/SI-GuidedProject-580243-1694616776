package com.example.hotelapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Dish11(val title: String, val imageDish: Int)

@Composable
fun Menu11(){

    val dishes11 = listOf(
        Dish11("Chicken Biryani", R.drawable.chicken_biryani),
        Dish11("Mutton Biryani", R.drawable.mutton_biryani),
        Dish11("Veg Biryani", R.drawable.veg_biryani)
    )

    LazyColumn{
        items(dishes11) { dish11 ->
            DishItem(dish11 = dish11)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DishItem(dish11: Dish11) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        onClick = {
            // Handle movie item click
        }
    ) {
        Column (
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ){
            Image(
                painter = painterResource(id = dish11.imageDish),
                contentDescription = dish11.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = dish11.title, fontWeight = FontWeight.Bold)
        }
    }
}