package com.example.hotelapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Dish32(val title: String, val imageDish: Int)

@Composable
fun Menu32(){

    val dishes32 = listOf(
        Dish32("Grilled Shrimp", R.drawable.grilled_shrimp),
        Dish32("Grilled Lobster", R.drawable.grilled_lobster),
        Dish32("Grilled Scallops", R.drawable.grilled_scallops)
    )

    LazyColumn{
        items(dishes32) { dish32 ->
            DishItem32(dish32 = dish32)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DishItem32(dish32: Dish32) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        onClick = {
            // Handle movie item click
        }
    ) {
        Column (
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ){
            Image(
                painter = painterResource(id = dish32.imageDish),
                contentDescription = dish32.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = dish32.title, fontWeight = FontWeight.Bold)
        }
    }
}